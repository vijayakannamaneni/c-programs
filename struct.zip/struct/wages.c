#include<stdio.h>
struct worker 
{
  char name[20];
  int wage;
  int wdays;
 };
 int main() 
 {
  struct worker w[2] ;
  int i,total;
  for(i=0;i<2;i++)
  {
  
  printf("enter the details of %d worker:\n",i+1);
  printf("enter worker name\t");
  scanf("%s",w[i].name);
  printf("enter wage for each day:\t ");
  scanf("%d",&w[i].wage);
  printf("enter the no.of working days:\t");
  scanf("%d",&w[i].wdays);
  int total=w[i].wage*w[i].wdays;
  printf("Name of first worker:%s\t Payment of worker:%d\t",w[i].name,total);
  
  printf("-------------------------------------\n"); 
}}

 
  
  
  
