#include<stdio.h>
#include<string.h>
  struct employee{
     int empno;
     char empname[20];
     int salary;  
     }a[10];
  int main()
  {
    int i,n;
    printf("\n enter number of employess\n  ");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
      printf("enter the details of %d employee\n ",i+1);
      printf("Number of employee:    ");
      scanf("%d",&a[i].empno);
      printf("enter employee name:    ");
      scanf("%s",a[i].empname);
      printf("enter salary of %d employee    :",i+1);
      scanf("%d",&a[i].salary);
    }
    int high=a[0].salary;
    for(i=0;i<n;i++)  
    {
        if(a[i].salary>high)
           high=a[i].salary;
     }
    printf("Highest salary employee details:");
    printf("\n-----------------------------\n");
    printf(" EMPNO\t NAME\tSALARY\n");
    for(i=0;i<n;i++)
   {
    if(a[i].salary==high)
    printf("\n %d\t%s\t%d\t",a[i].empno,a[i].empname,a[i].salary );
    }
    return 0;
   }

 
