#include<stdio.h>
struct attendance
{
  int id;
  char name[20];
  
};
   int main()
  {
  struct attendance c[2];
   for(int i=0;i<2;i++)
   {
   printf("enter the details of student %d\n",i+1);
   printf("##############");
   printf("enter id number of the student %d\n",i+1);
   scanf("%d",&c[i].id); 
   printf("enter name of the student %d\n",i+1);
   scanf("%s",c[i].name);
   }
   for(int i=0;i<2;i++)
   {
    printf("the details of the student %d\n",i+1);
    printf("the id of student is %d\n",c[i].id);
    printf("the name is %s\n",c[i].name);
   }}

  
