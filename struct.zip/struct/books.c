#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct book
{
   int bno,bcost,baccno;
   char bname[20],bpub[20],bauthor[20];
  }p[20];
  int main()
  {
    int n,i,ch;
    char pubname[20],authorname[20];
    printf("/*How many records of book u want to add*/\n:");
    scanf("%d",&n);
    printf("------------------------------------\n");
    for(i=0;i<n;i++)
    {
      printf("\t enter details of book-%d",i+1);
      printf("\n------------------------------\n");
      printf("book number:");
      scanf("%d",&p[i].bno);
      printf("book name    :");
      scanf("%s",p[i].bname);
     
      printf("Author name   :");  
      scanf("%s",p[i].bauthor);
      printf("Publication     :");
      scanf("%s",p[i].bpub);
      printf("cost      :");
      scanf("%d",&p[i].bcost);
      printf("Accession number");
      scanf("%d",&p[i].baccno);
      printf("-------------------------------\n");
    }
    while(1)
   {
     printf("\n\t\tMENU\n");
     printf("---------------------------------\n");
     printf("\n 1.Books of specific author");
     printf("\n 2.Books of specific publisher");
     printf("\n 3.All Books costing Rs.500 &above");
     printf("\n 4.All Books");
     printf("\n 5.Exit");
     printf("\n------------------------------------\n");
     printf("\nEnter your choice:");
     scanf("%d",&ch);
     printf("\n");
     switch(ch)
     {
       case 1:
             printf("Enter Author Name:");
             scanf("%s",authorname);
             for(i=0;i<n;i++)
             {
              if(strcmp(p[i].bauthor,authorname)==0)
                printf("\nBook Number  :%d\nBook name   :%s\n Accessnumber%d\n",p[i].bno,p[i].bname,p[i].baccno);
             } 
              break;
        case 2:
                    printf("Enter Publication Name : ");
                    scanf("%s",pubname);
                    for(i=0;i<n;i++)
                    {
                         if(strcmp(p[i].bpub,pubname)==0)
                              printf("\nBook Number      : %d\nBook Name        : %s\nAccession Number : %d\n\n",p[i].bno,p[i].bname,p[i].baccno);
                    }
                    break;
               case 3:
                    for(i=0;i<n;i++)
                    {
                         if(p[i].bcost>=500)
                         {
                              printf("Book Number : %d\n",p[i].bno);
                              printf("Book Name : %s \n",p[i].bname);
                              printf("Cost : %d\n",p[i].bcost);
                              printf("Accession Number : %d\n",p[i].baccno);
                              printf("\n------------------------------------------\n");
                         }
                    }
                    break;
               case 4:
                    for(i=0;i<n;i++)
                    {
                         printf("Book Number   : %d\n",p[i].bno);
                         printf("Book Name : %s \n",p[i].bname);
                         printf("Author : %s\n",p[i].bauthor);
                         printf("Publisher : %s\n",p[i].bpub);
                         printf("Cost : %d\n",p[i].bcost);
                         printf("Accession Number : %d\n",p[i].baccno);
                         printf("\n------------------------------------------\n");
                    }
                    break;
               case 5:
                    exit(0);
          }
     }
     return 0;
}
