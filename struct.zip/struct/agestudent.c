#include<stdio.h>
struct student
{
 int roll_num;
 char name[20]; 
 struct Date
 {
  int D;
  int M;
  int Y;
 }bd,ad;
 };
 int main()
 {
  int r;
  struct student a ;
  printf("\t Enter student details\n");
  printf("--------------------------\n");
  printf("enter roll_number");
  scanf("%d",&a.roll_num);
  printf("enter name    :");
  scanf("%s",a.name);
  printf("enter birth date    :");
  scanf("%d-%d-%d",&a.bd.D,&a.bd.M,&a.bd.Y);
  printf("enter admission date:");
  scanf("%d-%d-%d",&a.ad.D,&a.ad.M,&a.ad.Y);
  r=a.ad.Y-a.bd.Y;
  printf("-------------------------------\n");
  printf("\n Approximate age of the student at the time of admission ");
  printf("-----------------------------\n");
  printf("\t%d Years",r);
  return 0;
 }


