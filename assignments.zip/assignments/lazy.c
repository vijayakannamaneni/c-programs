#include<stdio.h>
 int lazy(int n)
 {   
   if (n==0)
   { 
      return 1;
   }
   else 
   {   return(n+lazy(n-1));
   }
}
void main()
{
  int n=5;
  int c;
  c=lazy(n);
  printf("%d %d",n,c);
}
   
  
    
  
