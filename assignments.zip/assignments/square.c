#include<stdio.h>
int main()
{
  int i,N=10,x;
  for(i=0;i<N;i++)
  {
    if(N%i==0)
    {
      printf("enter divisible number")
      scanf("%d",&x);
      printf("divisible %d",x);
    }
   else 
    {
      scanf("%d",&x);
      printf("not divisible %d",x);
     }
}
      
