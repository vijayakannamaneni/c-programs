#include<stdio.h>
int parity(int n)
 {
   int count=0;
   while(n>0)
   {  
      int k=n%2;
       n=n/2;
      if(k==1)
      {
         count++;
      }
   }
   if(count%2==0)
  {
    printf("even n");
   }
   else
  {
    printf("odd n");
  } 
  

}
int main()
{ 
  int n,k;
  printf("enter n");
  scanf("%d",&n);
  parity(n);
}
