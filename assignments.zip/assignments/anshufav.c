#include<stdio.h>

  int main()
 {
    int n;
    printf("enter the number ");
    scanf("%d",&n);
    if(n%5==0)
     {  
       printf("Yes the number can be writter as 5 multiple");
     }
    else
    {
     printf("No");
 
    }
 }
