#include<stdio.h>
int main()
{
  int n=3,i,sum=0;
  for(i=1;i<=n;i++)
  {
  
       sum=sum+(2*i-1)*(2*i-1);
 
   }
  
    printf("%d",sum);
}

  

