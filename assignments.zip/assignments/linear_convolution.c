/* linear convolution
total length=m+n-1;
any one array should be fixed and multiplied with another array by shifting and then added
this procdeure is called convolution*/


#include<stdio.h>
int main()
{
    int y[20],x[20],h[20],m,n,i,j,k;
    printf("enter the size of X: ");
    scanf("%d",&m);
    printf("enter the size of H: ");
    scanf("%d",&n);
    printf("Enter the x elements\n");
    k=m+n-1;
    for(i=0;i<m;i++)
    {
        scanf("%d",&x[i]);
        
    }
    for(i=m;i<k;i++)
    {
       x[i]= 0;//appending zero element
    }
    printf("x=");
    for(i=0;i<k;i++)
    {
        printf("%d",x[i]);
    }
    //h array elements
    printf("\nenter the H elements\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&h[i]);
        
    }
    for(i=n;i<k;i++)
    {
       h[i]= 0;
    }
     printf("h=");
     for(i=0;i<k;i++)
    {
        printf("%d",h[i]);
    }
    for(i=0;i<k;i++)
    {
        y[i]=0;
        for(j=0;j<=i;j++)
        {
            y[i]+=x[j]*h[i-j];
        }
    }
    printf("\nthe output sequence\n");
    for(i=0;i<k;i++)
    {
        printf("%d\n",y[i]);
    }
   
}
   


