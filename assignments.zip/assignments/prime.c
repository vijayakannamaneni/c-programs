#include<math.h>
#include<stdio.h>
int main()
{
	int i,n,n1,c=0;
        printf("enter the number u want to check");
	scanf("%d",&n);
        n1=ceil(sqrt(n));
      
        for(i=2;i<=n1 ;i++)

	{  if(n%i==0)
	    {
               c=1;
            }
         }
     if(c==0 && n!=1)
     {
         printf(" prime");
      }

      else
     {
        printf("not prime");
      }
}


           

       

