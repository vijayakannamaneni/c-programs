#include<stdio.h>
void checkevenodd(int n)
{
	int r=n%2;
	if(r==0)
	{  printf("the num  is even");
	}
	else
	{
          printf("the num  is odd");
        }

}
 int main()
{        int N;
	printf("enter any number");
         scanf("%d",&N);

	checkevenodd(N);

}
