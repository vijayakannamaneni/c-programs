#include<stdio.h>
int main()
{
  int sum=12,i,j;
  int arr[]={6,7,5,4};
  int n=sizeof(arr)/sizeof(arr[0]);
  for(i=0;i<n-1;i++)
  {
   for(j=0;j<n;j++)
    {
      if(arr[i]+arr[j]==sum)
      {
         printf("%d,%d\n",arr[i],arr[j]);
      }
  }
 }
}

