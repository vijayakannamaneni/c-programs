#include<stdio.h>
   int main()
 {
  
  int i,n,p=1;
  int arr[10];
  printf("enter n value ");
  scanf("%d",&n);
  for(i=0;i<n;i++)
  {
     scanf("%d",&arr[i]);
  } 
   printf("print the array %ls ",arr);
 
  for(i=0;i<n;i++)
  {
    p=p*arr[i];
 
   }
   for(i=0;i<n;i++)
   {
       arr[i]=p/arr[i] ;
    }
  printf("%d",arr[n]);


}

      
