#include<stdio.h>
int proarr(int  arr[],int n)
{
   int l[n],r[n],p[n];
    int i,j;
    l[0]=1;
    r[n-1]=1;
    for(i=1;i<n;i++)
    {
         l[i]=arr[i-1]*l[i-1];
    }
    for(j=n-2;j>=0;j--)
   {
        r[j]=arr[j+1]*r[j+1];
   }
   for(i=0;i<n;i++)
   {
       p[i]=l[i]*r[i];
   
   
   }
   for(i=0;i<n;i++)
   {
      printf("%d",p[i]);
      printf("%s"," ");
    }
   return 0;
  
}
int main()
{
   int arr[5]={10,1,2,3,4};
   int n=5;
   printf("the product arry is:\n ");
   proarr(arr,n);
}

  
