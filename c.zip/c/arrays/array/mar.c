#include<stdio.h>
  int mulmat(int mat1[][],int mat2[][])
  {
     int rslt[][];
     printf("multiplication of given two matrices is:\n\n");
     for(int i=0;i<R1;i++)
      {
	 for(int j=0;j<c2;j++)
         {
            rslt[i][j]=0;
            for(int k=0;k<R2;k++)
	    {
	      rslt[i][j] +=mat1[i][k] * mat2[k][j];
            }
            printf("%d\t",rslt[i][j]);
         }
       printf("\n");
      }
}
int main()
{  int mat1[][],mat2[][],R1,C2,R2,C1;
    printf("enter the no.of rows");
    scanf("%d",&R1);
     printf("enter no.of colomns");
     scanf("%d",&C1);
    printf("enter the first matrix=\n");
    for(i=0;i<R1;i++)
    {  for(j=0;j<C1;j++)
	{scanf("%d",&mat1[i][j]);
	}
     }
     printf("enter no.of rows and columns for mat2");
     scanf("%d""%d",&R2,&C2);
    printf("enter the elemets for second matrix");
    for(i=0;i<R2;i++)
     {
       for(j=0;j<C2;j++)
	{
          scanf("%d",&mat2[i][j]);
	}
     }
    if(C1!=R2)
    {
       printf("coumns of mat1 equal to columns of  mat2");
       exit(EXIT_FAILURE);
    }
    mulMat(mat1,mat2);
    return 0;
  }
	
     
    for(i=0;i<R2;i++)
    
	
  
