#include<stdio.h>
int binarysearch(int arr[],int low,int high,int x)
{
   int mid;
   while(low<high)
  {
   mid=low+(high-low)/2;
   if(arr[mid]==x)
     return mid;
   if(x>arr[mid])
     return binarysearch(arr,mid+1,high, x);
   if(x<arr[mid])
     return binarysearch(arr,0,mid-1, x);
  }
}
int main()
{
int arr[]={1,2,3,4,5};
int x=4;
int n=sizeof(arr)/sizeof(arr[0]);
int result=binarysearch(arr,0,n-1,x);
if(result==-1)
   printf("not found");
else
   printf("found at %d ",result);
}

