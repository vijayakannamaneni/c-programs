#include<stdio.h>
#include<math.h>
#include<complex.h>
 void DFT(int len)
 {
   int xn[len];
   float Xr[len];
   float Xi[len];
   int i, k, n;
   int  N;
   float z;
   for(i=0;i<len;i++)
   {
     printf("enter the values of xn[%d]",i);
     scanf("%d",&xn[i]);
   }
   printf("enter the no.of  points for DFT");
   scanf("%d",&N);
   for (k = 0; k < N; k++) {
		Xr[k] = 0;
		Xi[k] = 0;
		for (n = 0; n < len; n++) {
			Xr[k]
				= (Xr[k]
				+ xn[n] * cos(2 * 3.141592 * k * n / N));
			Xi[k]
				= (Xi[k]
				- xn[n] * sin(2 * 3.141592 * k * n / N));
		}
               float complex z=CMPLX(Xr[k],Xi[k]);
                  printf("z=%f +j %f\n",creal(z),cimag(z));
	}
}
   

   int main()
    {
      int len;
      printf("enter the lenght of sequnce:");
      scanf("%d",&len);
      DFT(len);
     }
