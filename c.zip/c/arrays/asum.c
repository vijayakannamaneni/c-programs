#include<stdio.h>
int sum(int arr[],int n)
{
   int i,sum=0;
   for(i=0;i<n;i++)
   {
     sum=sum+arr[i] ;
    }
    return sum;
}
int main()
{
  int arr[]={12,3,4,15};
 int n=sizeof(arr)/sizeof(arr[0]);
  printf("%d",sum(arr,n));
}
