#include<stdio.h>
int main()
{
	int values[5];
	printf("enter 5 integer");
	for(int i=0;i<5;i++)
	{
            scanf("%d",&values[i]);
        }
         for(int i=0;i<5;i++)
	{
	    printf("%d",values[i]);
	}

}
  
