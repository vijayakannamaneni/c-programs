#include<stdio.h>
int oddtimes(int arr[10],int n)
{
    int i,j,count=0;
    for(i=0;i<n;i++)
    {
      for(j=0;j<n;j++)
	{
           if(arr[i]==arr[j])
           {
             count++;
           }
        }
      if(count%2 !=0)
      {
        printf("%d\n %d",i,arr[i]);
      }
    }
   
   
}
 int main()
{
  int n,i,x,arr[10];
  printf("enter the no.of elements");
  scanf("%d",&n);
  printf("enter the array elements");
  for(i=0;i<n;i++)
  {
      scanf("%d",&arr[i]);
  } 
  (oddtimes(arr,n));

  return 0;
}



      
      
