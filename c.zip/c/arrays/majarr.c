#include<stdio.h>
    int major(int arr[],int n)
   {
     int maxcount=0;
     int index;
     for(int i=0;i<n;i++)
     {
       int count=0;
          for(int j=0;j<n;j++)

           if(arr[i]==arr[j])
           {    
              count++;
             
           }
        if(count>maxcount)
	{ 
           maxcount=count;
            index=i;
        }
      
       }
 
      if(maxcount>n/2)
      { 

        printf("the array element %d",arr[index]);
      }
      
    }
 
// Driver code
int main()
{
    int arr[] = { 1, 1, 2, 1, 3, 1, 1 };
    int n = sizeof(arr) / sizeof(arr[0]);
    
 
    // Function calling
    major(arr,n);
 
    return 0;
}
