#include<stdio.h>
#include<string.h>
int main()
 {
   char str[10]; 
   int i,j,count=0;
   char maxrepeated;
   int maxcount=0; 
   
   printf("enter a string");
   scanf("%s",str);
   for(i=0;i<strlen(str);i++)
   {
     for(j=0;j<strlen(str);j++)
     {
         if(str[i]==str[j])
          {
            count++;
          
          }
    }
   if(maxcount<count)
   {
     maxcount=count;
     maxrepeated=str[i];
   }
   }
   printf("the char %c is repeated  maximum %d times \n ",maxrepeated,maxcount);
  
   return 0;
  }
