#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>

 void *sum(void *arg);
 int num[2]={3,5};
 int main()
 {
  pthread_t a; 
  void *result;
  pthread_create(&a,NULL,sum,(void*)num);
  pthread_join(a,&result);
  printf("inside the main function\n");
 printf("thread returned     :%s\n",(char*)result);
  }
  void *sum(void *arg)
  {
   printf("inside the thread\n");
   int *x=arg;
   int sum=x[0]+x[1];
   printf("sum is %d\n",sum);
   pthread_exit("sum calculated");
 }
 
