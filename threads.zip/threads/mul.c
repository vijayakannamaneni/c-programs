#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#define MAX 2
 
 int matA[MAX][MAX];
  int matB[MAX][MAX];
  int matC[MAX][MAX];
    int i,j,k;

 void* mul(void* arg)
 {
    long int num1=(long int)arg;
   for(i=0;i<MAX;i++)
   {
    for(j=0;j<MAX;j++)
    { 
       matC[i][j]=0;
     for(k=0;k<MAX;k++)
      {
        matC[i][j]+=matA[i][k]*matB[k][j];
      }}} 
   } 
 
  void matrix_read()
 {
     printf("enter matrix A:");
    for(i=0;i<MAX;i++)
    {
     for(j=0;j<MAX;j++)
    {
      scanf("%d",&matA[i][j]);
    }}
     printf("enter matrix B");
    for(i=0;i<MAX;i++)
    {
     for(j=0;j<MAX;j++)
     {
      scanf("%d",&matB[i][j]);
     }}
   }

int main()
 {  
  
   pthread_t thread[MAX];
   matrix_read();
   for(i=0;i<MAX;i++)
   {
     pthread_create(&thread[i],NULL,&mul,(void**)&i);
   }
   for(i=0;MAX;i++)
   {
    pthread_join(thread[i],NULL);
   }

    for(i=0;i<MAX;i++)
      {
       for(j=0;j<MAX;j++)
       {
         printf("the resule matrix %d",matC[i][j])  ;
      }}
    
  }
  
