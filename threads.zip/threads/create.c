#include<stdio.h>
#include<pthread.h>
void* show(void *u)
  {
    printf("New Thread");
   }
  int main()
  { 
    pthread_t tid;
    pthread_create(&tid,NULL,&show,NULL);
    printf("Main Thread");

    pthread_join(tid,NULL);
    return 0;
  }
