#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>


int a=0;
void *fun(void *var)
{
   int *id=(int*)var;
   int a=7;
   static int b=0;
   b=7;
   printf("the id of thread is :%d\n",*id);
   printf("the value of static variable:%d\n",b);
   printf("the value of global variable:%d\n",a);
  }
 int main()
 {
      pthread_t th_id;
     for(int i=0;i<4;i++)
     {
        pthread_create(&th_id,NULL,&fun,(void*)&th_id);
     }
    pthread_exit(NULL);
     return 0;
 }

