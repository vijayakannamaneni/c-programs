#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<arpa/inet.h>
#include<string.h>


int main()
{
  int PORT=5566;
  char *ip="127.0.0.1";
  int sock,csock;
  char buffer[1024];
  struct sockaddr_in serv_addr,client_addr;
  
  sock=socket(AF_INET,SOCK_STREAM,0);
  if(sock<0)
  {
    perror("socket creation is failed");
    exit(1);
   }
  printf("[+] socket is created");
 
  serv_addr.sin_family=AF_INET;
  serv_addr.sin_addr.s_addr= inet_addr(ip);
  serv_addr.sin_port=PORT;
  
  int n=bind(sock,(struct sockaddr *)&serv_addr,sizeof(serv_addr));
  if(n<0)
  {
    perror("binding is failed");
   exit(1);
  }
  printf("[+] binded to port");
  
  listen(sock,5); 
  printf("listening .....");
  
 // while(1)
  //{
   int add_size=sizeof(client_addr);
   csock=accept(sock,(struct sockaddr*)&client_addr,&add_size);
   printf("client connected to socket ");
    bzero(buffer, 1024);
    recv(csock, buffer,strlen(buffer), 0);
    printf("Client: %s\n", buffer);

    bzero(buffer, 1024);
    strcpy(buffer, "HI, THIS IS SERVER. HAVE A NICE DAY!!!");
    printf("Server: %s\n", buffer);
    send(csock, buffer, strlen(buffer), 0);
   
    close(sock);
    printf("[+] server closed");
  
 
 // }
  return 0;
 }

  
