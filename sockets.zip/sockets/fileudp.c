#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<stdlib.h>
#define PORT 8000
#define SIZE 1024 

  void send_file_data(FILE *fp,int sock,struct sockaddr_in serv_addr)
  {
    int n;
    char buffer[1024];
   while(fgets(buffer, SIZE, fp) != NULL)
  {   
   printf("[SENDING] Data: %s", buffer);
   n= sendto(sock,buffer,SIZE,0,(struct sockaddr*)&serv_addr,sizeof(serv_addr));
    if(n<0)
    {
      perror("file sending failed\n");
      exit(1);
    }
    printf("File transfer is finished\n");
    bzero(buffer,1024);
  }
    strcpy(buffer,"END");
    sendto(sock,buffer,SIZE,0,(struct sockaddr*)&serv_addr,sizeof(serv_addr));
    fclose(fp);

   }
     
 
    int main()
{
  int sock;
  
  struct sockaddr_in serv_addr;
  char *filename="client.txt";
   FILE *fp=fopen(filename,"r");

  sock=socket(AF_INET,SOCK_DGRAM,0);
  if(sock<0)
  {
    perror("socket creation failed\n");
    exit(1);
  }
  printf("[+]socket creation  ");
  
  serv_addr.sin_family=AF_INET;
  serv_addr.sin_addr.s_addr=INADDR_ANY;
  serv_addr.sin_port=PORT;
 
  if(fp == NULL)
  {
    perror("file opening failed\n");
    exit(1);
   }
   send_file_data(fp, sock, serv_addr);

  printf("[SUCCESS] Data transfer complete.\n");
  printf("[CLOSING] Disconnecting from the server.\n");
  
  close(sock);
  return 0;
}
