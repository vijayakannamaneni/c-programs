#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#define PORT 8000
#define SIZE 1024

void write_file(int csock,struct sockaddr_in serv_addr)
 { 
   char* filename = "server2.txt";
  char buffer[SIZE];

  FILE* fp = fp = fopen(filename, "w");
   int c;
   while (1)
  {
   // addr_size = sizeof(addr);
    c = recv(csock, buffer, SIZE, 0);
    if (strcmp(buffer, "END") == 0)
    {
      break;
    }

    printf("[RECEVING] Data: %s", buffer);
    fprintf(fp, "%s", buffer);
    bzero(buffer, SIZE);
  }

  fclose(fp);
}



int main()
{
 int sock,csock,n;
 struct sockaddr_in serv_addr,client_addr;
 char buffer[1024];
 sock=socket(AF_INET,SOCK_STREAM,0);
 if(sock<0)
 {
   perror("[-]socket creation is failed");
   exit(1);
 }
 printf("socket is created\n");
 
 serv_addr.sin_family=AF_INET;
 serv_addr.sin_port=PORT;
 serv_addr.sin_addr.s_addr=INADDR_ANY;
 n=bind(sock,(struct sockaddr*)&serv_addr,sizeof(serv_addr));
 if(n<0)
 {
   perror("[-]binding is failed\n");
   exit(1);
 }
 printf("binded to port %d\n",PORT);
 
 int k=listen(sock,5);
 if(k<0)
 {
   perror("[-]listening failed");
   exit(1);
 }
 int len=sizeof(client_addr);
 csock=accept(sock,(struct sockaddr*)&client_addr,&len);

  write_file(csock,serv_addr);
 printf("[+]transferring is done\n");
 printf("[+]closing the socket\n");
 close(sock);
 }

 
 
 
 
