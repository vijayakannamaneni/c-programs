#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<sys/socket.h>
#define MAX 1024
#define PORT 8080

int main()
 {
    int csock,addr_len;
    char buffer[1024];
    struct sockaddr_in serv_addr;
    csock=socket(AF_INET6,SOCK_DGRAM,1);
    if(csock<0)
    {
      perror("[-]socket creation is failed");
      exit(1);
    
    }
    printf("socket is created");
    serv_addr.sin_addr=AF_INET6;
    serv_addr.sin_addr.s_addr=INADDR_ANY;
    serv_addr.sin_port=htons(PORT);
    addr_len=sizeof(serv_addr);
    bzero(buffer,1024);
    strcpy(buffer,"Client :Hlo server\n ");
    addr_len=sizeof(serv_addr);
    sendto(csock,buffer,MAX,MSG_CONFIRM,(const struct sockaddr *)&serv_addr,addr_len);
    printf("msg sent from client\n ");
    recvfrom(csock,buffer,MAX,MSG_WAITALL,(struct sockaddr *)&serv_addr,&addr_len);
     
    close(csock);
    return 0;
  }
