#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#include<unistd.h>
#define MAX 1024
#define PORT 8080

  int main() {
	int sock;
	char buffer[MAXLINE];
	struct sockaddr_in serv_addr, client_addr;
 
	if ( (sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
		perror("socket creation failed");
		exit(EXIT_FAILURE);
	}
		
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(PORT);
	if ( bind(sock, (const struct sockaddr *)&serv_addr,
			sizeof(serv_addr)) < 0 )
	{
		perror("bind failed");
		exit(EXIT_FAILURE);
	}
  printf("[+]bind to port");
 
  int addr_len=sizeof(client_addr);
  recvfrom(sock,(char *)buffer,MAX,MSG_WAITALL,(struct sockaddr *)&client_addr,&addr_len);
  bzero(buffer,1024);  
  strcpy(buffer,"server : HI  ");
  sendto(sock,buffer,MAX,MSG_CONFIRM,(const struct sockaddr *)&client_addr,addr_len);
  printf("hello msg sent from server \n:");

  
  return 0;
 }
  
  
