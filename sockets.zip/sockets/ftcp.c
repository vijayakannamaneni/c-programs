#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<string.h>
#define SIZE 1024
#define PORT 8000

  void send_file(FILE *fp,int sock_fd,struct sockaddr_in servaddr)
  {
    char buffer[SIZE];
    //char *filename="client.txt";
   // FILE *fp=fp=fopen(filename,"r");
    while(fgets(buffer,SIZE,fp)!=NULL)
   {
    int n=send(sock_fd,buffer,SIZE,0);
    if(n<0)
    {
      perror("[-]failed to send\n");
      exit(1);
    }
    printf("%s",buffer);
    bzero(buffer,1024);
   }
    strcpy(buffer,"END");
    send(sock_fd,buffer,SIZE,0);
    printf("send the data to server\n");
    fclose(fp);
    
   }
        




int main()
{
  int sock_fd;
  struct sockaddr_in serv_addr;
  char *filename="client.txt";
  FILE *fp=fopen(filename,"r");
  sock_fd=socket(AF_INET,SOCK_STREAM,0);
  if(sock_fd<0)
  {
    perror("[+]socket creation failed\n");
    exit(1);
  }
  printf("socket is created\n");
  serv_addr.sin_family=AF_INET;
  serv_addr.sin_addr.s_addr=INADDR_ANY;
  serv_addr.sin_port=PORT;
  connect(sock_fd,(struct sockaddr*)&serv_addr,sizeof(serv_addr));
  printf("[+]connected to server\n");
    if (fp == NULL)
  {
    perror("[ERROR] reading the file");
    exit(1);
  }
  
  send_file(fp,sock_fd,serv_addr);
  printf("[+]transferring files\n");
  printf("disconnecting from server\n");
 
  close(sock_fd);
  return 0;
 }
