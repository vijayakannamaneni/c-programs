#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
#include<arpa/inet.h>
#include<sys/socket.h>
#define SIZE 1024
#define PORT 8000

  void write_file(int sock,struct sockaddr_in client_addr)
  { 
    char buffer[1024];
    char* filename="server1.txt";
    int n,len;
     FILE* fp = fp = fopen(filename, "w");
    len=sizeof(client_addr);
    while(1)
    {

      n=recvfrom(sock,buffer,SIZE,0,(struct sockaddr *)&client_addr,&len);
     
      if(strcmp(buffer,"END")==0)
      {
        break;
      }
      printf("%s",buffer);
      fprintf(fp,"%s",buffer);
      bzero(buffer,1024);
      }
      fclose(fp);   
}
int main()

{
  int sock ;
  struct sockaddr_in serv_addr,client_addr;
  int n;
  sock=socket(AF_INET,SOCK_DGRAM,0);
  if(sock<0)
  {
    perror("socket creation failed\n");
    exit(1);
  }
  printf("socket is created\n");

  serv_addr.sin_family=AF_INET;
  serv_addr.sin_port=PORT;
  serv_addr.sin_addr.s_addr=INADDR_ANY;

  n= bind(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
  if (n< 0)
  {
    perror("[ERROR] bind error");
    exit(1);
  }

  printf("[STARTING] UDP File Server started. \n");
  write_file(sock, client_addr);

  printf("[SUCCESS] Data transfer complete.\n");
  printf("[CLOSING] Closing the server.\n");

  close(sock);

  return 0;

 
 }

 

