//Given a array a[] of non-negative integers. Count the number of pairs (i, j) in the array such that a[i] + a[j] < a[i]*a[j]. (the pair (i, j) and (j, i) are considered same and i should not be equal to j)



#include <stdio.h>
// such that arr[i] * arr[j] > arr[i] + arr[j]
int countpairs(int arr[], int n)
{
	int count = 0;
	for (int i = 0; i < n - 1; i++) {
		for (int j = i + 1; j < n; j++) {

			// If condition is satisfied
			if (arr[i] + arr[j] < arr[i] * arr[j])
				count++;
		}
               

	}
        printf("%d",count);
	
}

int main()
{
	int arr[] = { 3,4,3 };
	int n = sizeof(arr) / sizeof(arr[0]);
	countpairs(arr,n);
        
	
}

