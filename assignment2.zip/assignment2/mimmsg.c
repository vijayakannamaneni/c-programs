#include<stdio.h>
int main()
 {
   int n,c;
   printf("no.of students ");
   scanf("%d",&n);
   c=2*(n-1);
   printf("%d",c);
 }

