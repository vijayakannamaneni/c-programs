#include<stdio.h>
#include<string.h>
#include<math.h>

int todigit(char c)
{
	return (c - '0');
}
int main()
{
 char num[10]="421";
 int n=strlen(num);
 int prev=todigit(num[0]);
 int res=prev;
 int curr=0;
 for(int i=1;i<n;i++)
 {
   int temp=todigit(num[i]);
   curr=(i+1)*temp+10*prev;
   res+=curr;
  prev=curr;
 }
  printf("%d",res);
  return 0;
}


