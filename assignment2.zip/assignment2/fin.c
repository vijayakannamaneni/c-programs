#include <stdio.h>
int altPoduct(int A[],int N)
{   int even[N/2];
    int odd[N/2];
    int i;
    int j;
    int temp;
    int swap;
    /*sorting of original array */
    for (i=0;i<N-1;++i)
    {
        swap = 0 ;
        for(j=0;j<N-i-1;++j)
        {
            if(A[j]>A[j+1])
            {
                temp=A[j];
                A[j]=A[j+1];
                A[j+1]=temp;
                swap = 1 ;
            }
        }
        if (swap=0)
            break;
    }
    // Getting elemets in even index to even array
    for (i=0,j=0;i<N;i++)
    {
        if(i%2==0)
        {
            even[j]=A[i];
            j=j+1;
         }
    }
    //getting odd index elements to odd array
    
    for (i=0,j=0;i<N;i++)
    {
        if(i%2!=0)
        {
            odd[j]=A[i];
            j=j+1;
         }
    }
    // revers sorting even array or we can sort odd array
    for (i=0;i<N/2-1;++i)
    {
        swap = 0;
        for(j=0;j<N/2-i-1;++j)
        {
            if(even[j]<even[j+1])
            {
                temp=even[j];
                even[j]=even[j+1];
                even[j+1]=temp;
                swap = 1;
            }
        }
        if (swap==0)
            break;
    }
    // calculating minimum sum
    int sum=0 ;
    for (i=0,j=0;i<N/2;i++)
    {
        A[j]=even[i];
        j=j+1;
        A[j]=odd[i];
        j=j+1;
        sum += even[i]*odd[i];
    }
    return sum;
}

int main()
{
    
    int A[] ={1,2,3,4} ;
    int N =sizeof(A)/sizeof(A[0]);
    printf("%d\n",N);
    for (int i=0;i<N;i++)
    printf("%d ",A[i]);
    printf("\n%d\n",altPoduct(A,N));

}


