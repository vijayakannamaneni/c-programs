//Given an sorted array A of size N. Find number of elements which are less than or equal to given element X.
#include<stdio.h>
int main()
{ 
  int n=5;
  int arr[]={1,2,3,4,5};
  int key=4,count=0;
  for(int i=0;i<n;i++)
  {
    if(arr[i]<=key)
       count++;
  } 
   printf("%d",count);
}
