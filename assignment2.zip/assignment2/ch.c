#include <stdio.h>
#include <math.h>
int setAllBits(int n)
{
      int temp = n,i,j,bits[10],flag=0,org[10];
      
      // dec to binar
      for(i=0;temp>0;i++)
      {
          bits[i] = temp%2;
          temp = temp/2;
          flag++  ;
      }
      //for (i=0;i<flag;i++)
        //printf("bits[%d]=%d\n",i,bits[i]);
      
      // changing odd index of o bits to one 
      for (i=0;i<flag;i++)
      {
         if(i%2==0 && bits[i]==0)
            org[i]=1;
         else
            org[i]=bits[i];
      }
      
      // reversing the bits
      
      for (i=flag-1,j=0;i>=0;i--)
      {
        bits[j]=org[i];
        j=j+1;
      }
      
      //for (i=0;i<flag;i++)
        //printf("bits[%d]=%d\n",i,bits[i]);
      
       
      // binary to decimal
      n=0;
      for (i=0;i<flag;i++)     
        n+=bits[i]*pow(2,i);
      
      return n;
      
}

int main()
{
    int n=10;
    printf("%d\n",n);
    printf("%d\n",setAllBits(n));
}


