//Given two numbers M and N. The task is to find the position of the rightmost different bit in the binary representation of numbers.
#include<stdio.h>
#include<math.h>
int main()
{ 
    int M=52,N=4;
   int temp=M^N;
     int pos=1;
     for(int i=0;i<sizeof(int);i++)
      {
         if(!(temp&(1<<i)))
           pos++;
        else
           break;
       }
      printf("%d",pos);
      return 0;
}
